/*
* Copyright 2025 NXP
* NXP Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "widgets_init.h"
#include "custom.h"



void setup_scr_screen_logo(lv_ui *ui)
{
    //Write codes screen_logo
    ui->screen_logo = lv_obj_create(NULL);
    lv_obj_set_size(ui->screen_logo, 320, 170);
    lv_obj_set_scrollbar_mode(ui->screen_logo, LV_SCROLLBAR_MODE_OFF);

    //Write style for screen_logo, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_bg_opa(ui->screen_logo, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

    //Write codes screen_logo_img_1
    ui->screen_logo_img_1 = lv_image_create(ui->screen_logo);
    lv_obj_set_pos(ui->screen_logo_img_1, 0, 0);
    lv_obj_set_size(ui->screen_logo_img_1, 320, 170);
    lv_obj_add_flag(ui->screen_logo_img_1, LV_OBJ_FLAG_CLICKABLE);
    lv_image_set_src(ui->screen_logo_img_1, &_background_RGB565A8_320x170);
    lv_image_set_pivot(ui->screen_logo_img_1, 50,50);
    lv_image_set_rotation(ui->screen_logo_img_1, 0);

    //Write style for screen_logo_img_1, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_image_recolor_opa(ui->screen_logo_img_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_image_opa(ui->screen_logo_img_1, 255, LV_PART_MAIN|LV_STATE_DEFAULT);

    //Write codes screen_logo_label_1
    ui->screen_logo_label_1 = lv_label_create(ui->screen_logo);
    lv_obj_set_pos(ui->screen_logo_label_1, 90, 20);
    lv_obj_set_size(ui->screen_logo_label_1, 150, 15);
    lv_label_set_text(ui->screen_logo_label_1, "WELCOME TO MAK");
    lv_label_set_long_mode(ui->screen_logo_label_1, LV_LABEL_LONG_WRAP);

    //Write style for screen_logo_label_1, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_border_width(ui->screen_logo_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_radius(ui->screen_logo_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(ui->screen_logo_label_1, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui->screen_logo_label_1, &lv_font_Enriqueta_Regular_16, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui->screen_logo_label_1, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_letter_space(ui->screen_logo_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_line_space(ui->screen_logo_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_align(ui->screen_logo_label_1, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui->screen_logo_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_top(ui->screen_logo_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_right(ui->screen_logo_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_bottom(ui->screen_logo_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_left(ui->screen_logo_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_width(ui->screen_logo_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

    //Write codes screen_logo_img_2
    ui->screen_logo_img_2 = lv_image_create(ui->screen_logo);
    lv_obj_set_pos(ui->screen_logo_img_2, 55, 45);
    lv_obj_set_size(ui->screen_logo_img_2, 215, 100);
    lv_obj_add_flag(ui->screen_logo_img_2, LV_OBJ_FLAG_CLICKABLE);
    lv_image_set_src(ui->screen_logo_img_2, &_logo_RGB565A8_215x100);
    lv_image_set_pivot(ui->screen_logo_img_2, 50,50);
    lv_image_set_rotation(ui->screen_logo_img_2, 0);

    //Write style for screen_logo_img_2, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_image_recolor_opa(ui->screen_logo_img_2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_image_opa(ui->screen_logo_img_2, 255, LV_PART_MAIN|LV_STATE_DEFAULT);

    //The custom code of screen_logo.


    //Update current screen layout.
    lv_obj_update_layout(ui->screen_logo);

    //Init events for screen.
    events_init_screen_logo(ui);
}
