/*
* Copyright 2025 NXP
* NXP Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#ifndef GUI_GUIDER_H
#define GUI_GUIDER_H
#ifdef __cplusplus
extern "C" {
#endif

#include "lvgl.h"


typedef struct
{
  
	lv_obj_t *screen_logo;
	bool screen_logo_del;
	lv_obj_t *screen_logo_img_1;
	lv_obj_t *screen_logo_label_1;
	lv_obj_t *screen_logo_img_2;
	lv_obj_t *screen_1;
	bool screen_1_del;
	lv_obj_t *screen_1_img_1;
	lv_obj_t *screen_1_img_2;
	lv_obj_t *screen_1_img_3;
	lv_obj_t *screen_1_label_1;
	lv_obj_t *screen_1_img_4;
	lv_obj_t *screen_1_label_2;
	lv_obj_t *screen_1_label_3;
	lv_obj_t *screen_1_label_6;
	lv_obj_t *screen_1_img_5;
	lv_obj_t *screen_1_img_6;
	lv_obj_t *screen_1_label_7;
	lv_obj_t *screen_1_bar_2;
	lv_obj_t *screen_1_label_8;
	lv_obj_t *screen_1_img_7;
	lv_obj_t *screen_1_img_8;
	lv_obj_t *screen_1_img_9;
	lv_obj_t *screen_1_img_10;
	lv_obj_t *screen_1_label_9;
	lv_obj_t *screen_1_label_10;
	lv_obj_t *screen_1_img_11;
	lv_obj_t *screen_1_label_11;
	lv_obj_t *screen_1_label_12;
	lv_obj_t *screen_1_label_13;
	lv_obj_t *screen_1_label_14;
	lv_obj_t *screen_1_label_15;
	lv_obj_t *screen_1_label_16;
	lv_obj_t *screen_1_img_12;
	lv_obj_t *screen_1_img_13;
	lv_obj_t *screen_1_img_14;
	lv_obj_t *screen_1_btn_1;
	lv_obj_t *screen_1_btn_1_label;
	lv_obj_t *screen_2;
	bool screen_2_del;
	lv_obj_t *screen_2_img_1;
	lv_obj_t *screen_2_img_2;
	lv_obj_t *screen_2_img_3;
	lv_obj_t *screen_2_label_1;
	lv_obj_t *screen_2_img_4;
	lv_obj_t *screen_2_label_2;
	lv_obj_t *screen_2_label_3;
	lv_obj_t *screen_2_label_6;
	lv_obj_t *screen_2_img_5;
	lv_obj_t *screen_2_img_6;
	lv_obj_t *screen_2_label_7;
	lv_obj_t *screen_2_bar_2;
	lv_obj_t *screen_2_label_8;
	lv_obj_t *screen_2_img_7;
	lv_obj_t *screen_2_img_8;
	lv_obj_t *screen_2_img_9;
	lv_obj_t *screen_2_img_10;
	lv_obj_t *screen_2_label_9;
	lv_obj_t *screen_2_label_10;
	lv_obj_t *screen_2_img_11;
	lv_obj_t *screen_2_label_11;
	lv_obj_t *screen_2_label_12;
	lv_obj_t *screen_2_label_13;
	lv_obj_t *screen_2_label_14;
	lv_obj_t *screen_2_label_15;
	lv_obj_t *screen_2_label_16;
	lv_obj_t *screen_2_img_12;
	lv_obj_t *screen_2_img_13;
	lv_obj_t *screen_2_img_14;
	lv_obj_t *screen_2_btn_1;
	lv_obj_t *screen_2_btn_1_label;
}lv_ui;

typedef void (*ui_setup_scr_t)(lv_ui * ui);

void ui_init_style(lv_style_t * style);

void ui_load_scr_animation(lv_ui *ui, lv_obj_t ** new_scr, bool new_scr_del, bool * old_scr_del, ui_setup_scr_t setup_scr,
                           lv_screen_load_anim_t anim_type, uint32_t time, uint32_t delay, bool is_clean, bool auto_del);

void ui_animation(void * var, uint32_t duration, int32_t delay, int32_t start_value, int32_t end_value, lv_anim_path_cb_t path_cb,
                  uint32_t repeat_cnt, uint32_t repeat_delay, uint32_t playback_time, uint32_t playback_delay,
                  lv_anim_exec_xcb_t exec_cb, lv_anim_start_cb_t start_cb, lv_anim_completed_cb_t ready_cb, lv_anim_deleted_cb_t deleted_cb);


void init_scr_del_flag(lv_ui *ui);

void setup_bottom_layer(void);

void setup_ui(lv_ui *ui);

void video_play(lv_ui *ui);

void init_keyboard(lv_ui *ui);

extern lv_ui guider_ui;


void setup_scr_screen_logo(lv_ui *ui);
void setup_scr_screen_1(lv_ui *ui);
void setup_scr_screen_2(lv_ui *ui);
LV_IMAGE_DECLARE(_background_RGB565A8_320x170);
LV_IMAGE_DECLARE(_logo_RGB565A8_215x100);
LV_IMAGE_DECLARE(_Battery_3d_RGB565A8_93x142);
LV_IMAGE_DECLARE(_squarebox_RGB565A8_79x58);
LV_IMAGE_DECLARE(_rectangle_box_RGB565A8_68x111);
LV_IMAGE_DECLARE(_Battery2_RGB565A8_42x84);
LV_IMAGE_DECLARE(_squarebox_RGB565A8_62x38);
LV_IMAGE_DECLARE(_heart_RGB565A8_12x10);
LV_IMAGE_DECLARE(_cycle_RGB565A8_12x12);
LV_IMAGE_DECLARE(_remain_time2_RGB565A8_12x15);
LV_IMAGE_DECLARE(_voltage_RGB565A8_10x10);
LV_IMAGE_DECLARE(_current_RGB565A8_12x10);

LV_FONT_DECLARE(lv_font_Enriqueta_Regular_16)
LV_FONT_DECLARE(lv_font_montserratMedium_16)
LV_FONT_DECLARE(lv_font_Enriqueta_Medium_14)
LV_FONT_DECLARE(lv_font_Enriqueta_Regular_7)
LV_FONT_DECLARE(lv_font_Enriqueta_Regular_12)
LV_FONT_DECLARE(lv_font_Enriqueta_Medium_10)
LV_FONT_DECLARE(lv_font_Enriqueta_Regular_18)
LV_FONT_DECLARE(lv_font_Enriqueta_Regular_6)
LV_FONT_DECLARE(lv_font_montserratMedium_10)
LV_FONT_DECLARE(lv_font_montserratMedium_12)


#ifdef __cplusplus
}
#endif
#endif
